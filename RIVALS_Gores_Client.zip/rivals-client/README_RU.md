ВЕРСИЯ: основа — DDNetGores/client (Tater-Client), релиз 18.0.2
https://github.com/DDNetGores/client/releases
Готовый архив в Actions будет называться RIVALS-Gores-Client-win64.

# RIVALS Client (на базе DDNet)

Клиент собирается из **официального исходника DDNet** (github.com/ddnet/ddnet) + наших изменений.
Мы не храним весь DDNet в репозитории: GitHub Actions сам скачивает DDNet, накладывает патчи и собирает `.exe`.

## Что добавлено
- Вкладка **RIVALS** в настройках (после «Credits»).
- **Свои шрифты**: список всех `.ttf/.otf` из папки `data/fonts`, выбор в один клик + кнопка «Перезапуск». Оригинальный шрифт остаётся запасным (кириллица не ломается).
- **Музыка «Сейчас играет»** из Spotify, браузеров (YouTube, Яндекс Музыка, VK…), плееров — через Windows Media Session. Карточка с управлением в настройках и HUD сверху в игре.
- Консольные команды для биндов: `rivals_music_toggle`, `rivals_music_next`, `rivals_music_prev`, `rivals_music_source`.

## Структура
```
overlay/src/...            наши новые файлы (копируются в DDNet)
scripts/apply_rivals.py    правки файлов DDNet по «якорям»
data/fonts/                положи сюда свои .ttf/.otf — попадут в сборку
.github/workflows/build.yml  сборка Windows в GitHub Actions
```

## Как собрать (без установки чего-либо на ПК)
1. Создай пустой репозиторий на GitHub, например `rivals-client`.
2. Загрузи туда содержимое этого архива (через «Add file → Upload files» или `git push`). Папка `.github` обязательна.
3. Открой вкладку **Actions** → «Build RIVALS Client». Сборка запускается сама (≈20–30 мин).
4. Готовый `RIVALS-Gores-Client-win64.zip` — внизу страницы запуска, в разделе **Artifacts**.
5. Для релиза: создай тег `v1.0` (Releases → Draft new release → тег `v1.0`) — zip прикрепится автоматически.

## Если сборка упала
- `[ОШИБКА] якорь не найден` — DDNet поменял код. Поставь в `build.yml` `DDNET_REF: 19.4` (или другой тег) или пришли лог — обновлю якорь.
- Ошибка компиляции — пришли кусок лога с `error C...`, поправлю.

## Локальная сборка (по желанию)
```
git clone --recursive https://github.com/ddnet/ddnet
python scripts/apply_rivals.py ddnet
cd ddnet && mkdir build && cd build
cmake -A x64 -DVULKAN=OFF .. && cmake --build . --config Release --target game-client
```
Нужны Visual Studio 2022 (C++), CMake, Rust, Python.

Читов нет — только визуал и удобство, поэтому клиент безопасен для серверов DDNet.
