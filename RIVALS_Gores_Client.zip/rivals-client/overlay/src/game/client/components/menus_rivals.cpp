/* RIVALS: вкладка настроек — выбор шрифта и музыка из Spotify / браузера / плееров. */
#include <base/system.h>
#include <engine/client.h>
#include <engine/shared/config.h>
#include <engine/storage.h>
#include <engine/textrender.h>

#include <game/client/components/menus.h>
#include <game/client/components/rivals/music_hud.h>
#include <game/client/gameclient.h>
#include <game/client/ui.h>
#include <game/client/ui_listbox.h>
#include <game/localization.h>

#include <algorithm>
#include <string>
#include <vector>

namespace
{
constexpr int MAX_FONTS = 256;
std::vector<std::string> gs_vRivalsFonts;
bool gs_RivalsFontsScanned = false;
bool gs_RivalsFontChanged = false;
char gs_aRivalsFontIds[MAX_FONTS + 1];

int RivalsFontScanCallback(const char *pName, int IsDir, int StorageType, void *pUser)
{
	if(IsDir)
		return 0;
	if(!str_endswith_nocase(pName, ".ttf") && !str_endswith_nocase(pName, ".otf"))
		return 0;
	auto *pList = static_cast<std::vector<std::string> *>(pUser);
	if((int)pList->size() < MAX_FONTS && std::find(pList->begin(), pList->end(), pName) == pList->end())
		pList->emplace_back(pName);
	return 0;
}
} // namespace

void CMenus::RenderSettingsRivals(CUIRect MainView)
{
	if(!gs_RivalsFontsScanned)
	{
		gs_vRivalsFonts.clear();
		// data/fonts и %APPDATA%/DDNet/fonts
		Storage()->ListDirectory(IStorage::TYPE_ALL, "fonts", RivalsFontScanCallback, &gs_vRivalsFonts);
		std::sort(gs_vRivalsFonts.begin(), gs_vRivalsFonts.end(), [](const std::string &a, const std::string &b) { return str_comp_nocase(a.c_str(), b.c_str()) < 0; });
		gs_RivalsFontsScanned = true;
	}

	CUIRect Left, Right, Label, Button;
	MainView.Margin(10.0f, &MainView);
	MainView.VSplitMid(&Left, &Right, 20.0f);

	// ===================== ШРИФТЫ =====================
	Left.HSplitTop(24.0f, &Label, &Left);
	Ui()->DoLabel(&Label, Localize("Шрифт"), 20.0f, TEXTALIGN_ML);
	Left.HSplitTop(5.0f, nullptr, &Left);

	CUIRect ButtonsRow, RestartRow;
	Left.HSplitBottom(20.0f, &Left, &ButtonsRow);
	Left.HSplitBottom(5.0f, &Left, nullptr);
	if(gs_RivalsFontChanged)
	{
		Left.HSplitBottom(20.0f, &Left, &RestartRow);
		Left.HSplitBottom(5.0f, &Left, nullptr);
	}

	int Selected = 0; // 0 = стандартный
	for(size_t i = 0; i < gs_vRivalsFonts.size(); i++)
		if(str_comp(gs_vRivalsFonts[i].c_str(), g_Config.m_ClRivalsFont) == 0)
			Selected = (int)i + 1;

	static CListBox s_FontList;
	const int NumItems = (int)gs_vRivalsFonts.size() + 1;
	s_FontList.DoStart(20.0f, NumItems, 1, 3, Selected, &Left);
	for(int i = 0; i < NumItems; i++)
	{
		const CListboxItem Item = s_FontList.DoNextItem(&gs_aRivalsFontIds[i], i == Selected);
		if(!Item.m_Visible)
			continue;
		CUIRect ItemLabel;
		Item.m_Rect.VMargin(5.0f, &ItemLabel);
		const char *pName = i == 0 ? Localize("Стандартный (DDNet)") : gs_vRivalsFonts[i - 1].c_str();
		Ui()->DoLabel(&ItemLabel, pName, 12.0f, TEXTALIGN_ML);
	}
	const int NewSelected = s_FontList.DoEnd();
	if(NewSelected != Selected && NewSelected >= 0 && NewSelected < NumItems)
	{
		str_copy(g_Config.m_ClRivalsFont, NewSelected == 0 ? "" : gs_vRivalsFonts[NewSelected - 1].c_str(), sizeof(g_Config.m_ClRivalsFont));
		gs_RivalsFontChanged = true;
	}

	if(gs_RivalsFontChanged)
	{
		CUIRect RestartLabel, RestartButton;
		RestartRow.VSplitRight(120.0f, &RestartLabel, &RestartButton);
		TextRender()->TextColor(ColorRGBA(1.0f, 0.85f, 0.3f, 1.0f));
		Ui()->DoLabel(&RestartLabel, Localize("Шрифт применится после перезапуска"), 12.0f, TEXTALIGN_ML);
		TextRender()->TextColor(TextRender()->DefaultTextColor());
		static CButtonContainer s_RestartButton;
		if(DoButton_Menu(&s_RestartButton, Localize("Перезапустить"), 0, &RestartButton))
			Client()->Restart();
	}

	{
		CUIRect RescanButton, FolderButton;
		ButtonsRow.VSplitMid(&RescanButton, &FolderButton, 5.0f);
		static CButtonContainer s_RescanButton, s_FolderButton;
		if(DoButton_Menu(&s_RescanButton, Localize("Обновить список"), 0, &RescanButton))
			gs_RivalsFontsScanned = false;
		if(DoButton_Menu(&s_FolderButton, Localize("Папка шрифтов"), 0, &FolderButton))
		{
			char aBuf[IO_MAX_PATH_LENGTH];
			Storage()->CreateFolder("fonts", IStorage::TYPE_SAVE);
			Storage()->GetCompletePath(IStorage::TYPE_SAVE, "fonts", aBuf, sizeof(aBuf));
			Client()->ViewFile(aBuf); // в старых версиях DDNet: open_file(aBuf);
		}
	}

	// ===================== МУЗЫКА =====================
	CRivalsMusicHud &MusicHud = GameClient()->m_RivalsMusicHud;

	Right.HSplitTop(24.0f, &Label, &Right);
	Ui()->DoLabel(&Label, Localize("Музыка"), 20.0f, TEXTALIGN_ML);
	Right.HSplitTop(5.0f, nullptr, &Right);

	if(!CRivalsMediaSession::Supported())
	{
		Right.HSplitTop(20.0f, &Label, &Right);
		Ui()->DoLabel(&Label, Localize("Работает только на Windows 10/11"), 12.0f, TEXTALIGN_ML);
		return;
	}

	// карточка текущего трека
	const SRivalsTrack Track = MusicHud.Media().Get();
	CUIRect Card;
	Right.HSplitTop(CRivalsMusicHud::InfoHeight(14.0f), &Card, &Right);
	if(Track.m_Available)
		MusicHud.RenderInfo(Card, Track, 14.0f);
	else
	{
		Card.Draw(ColorRGBA(0.0f, 0.0f, 0.0f, 0.3f), IGraphics::CORNER_ALL, 8.0f);
		Ui()->DoLabel(&Card, Localize("Музыка не играет — включи трек в Spotify или браузере"), 12.0f, TEXTALIGN_MC);
	}
	Right.HSplitTop(8.0f, nullptr, &Right);

	// управление
	{
		CUIRect Controls, Prev, Toggle, Next, Source;
		Right.HSplitTop(24.0f, &Controls, &Right);
		Controls.VSplitLeft(50.0f, &Prev, &Controls);
		Controls.VSplitLeft(5.0f, nullptr, &Controls);
		Controls.VSplitLeft(90.0f, &Toggle, &Controls);
		Controls.VSplitLeft(5.0f, nullptr, &Controls);
		Controls.VSplitLeft(50.0f, &Next, &Controls);
		Controls.VSplitLeft(10.0f, nullptr, &Source);

		static CButtonContainer s_PrevButton, s_ToggleButton, s_NextButton, s_SourceButton;
		if(DoButton_Menu(&s_PrevButton, "<<", 0, &Prev))
			MusicHud.Media().Send(CRivalsMediaSession::CMD_PREV);
		if(DoButton_Menu(&s_ToggleButton, Track.m_Playing ? Localize("Пауза") : Localize("Играть"), 0, &Toggle))
			MusicHud.Media().Send(CRivalsMediaSession::CMD_TOGGLE);
		if(DoButton_Menu(&s_NextButton, ">>", 0, &Next))
			MusicHud.Media().Send(CRivalsMediaSession::CMD_NEXT);

		char aSource[128];
		str_format(aSource, sizeof(aSource), "%s (%d)", Localize("Сменить источник"), Track.m_SessionCount);
		if(DoButton_Menu(&s_SourceButton, aSource, Track.m_SessionCount > 1 ? 0 : -1, &Source) && Track.m_SessionCount > 1)
			MusicHud.Media().Send(CRivalsMediaSession::CMD_NEXT_SOURCE);
	}
	Right.HSplitTop(15.0f, nullptr, &Right);

	// настройки плеера в игре
	Right.HSplitTop(20.0f, &Button, &Right);
	if(DoButton_CheckBox(&g_Config.m_ClRivalsMusicHud, Localize("Показывать плеер сверху во время игры"), g_Config.m_ClRivalsMusicHud, &Button))
		g_Config.m_ClRivalsMusicHud ^= 1;

	Right.HSplitTop(20.0f, &Button, &Right);
	if(DoButton_CheckBox(&g_Config.m_ClRivalsMusicHudHidePaused, Localize("Скрывать, когда музыка на паузе"), g_Config.m_ClRivalsMusicHudHidePaused, &Button))
		g_Config.m_ClRivalsMusicHudHidePaused ^= 1;

	Right.HSplitTop(5.0f, nullptr, &Right);
	Right.HSplitTop(20.0f, &Button, &Right);
	{
		const char *apAlign[] = {Localize("Слева"), Localize("По центру"), Localize("Справа")};
		char aBuf[128];
		str_format(aBuf, sizeof(aBuf), "%s: %s", Localize("Положение"), apAlign[clamp(g_Config.m_ClRivalsMusicHudAlign, 0, 2)]);
		static CButtonContainer s_AlignButton;
		if(DoButton_Menu(&s_AlignButton, aBuf, 0, &Button))
			g_Config.m_ClRivalsMusicHudAlign = (g_Config.m_ClRivalsMusicHudAlign + 1) % 3;
	}

	Right.HSplitTop(5.0f, nullptr, &Right);
	Right.HSplitTop(20.0f, &Button, &Right);
	Ui()->DoScrollbarOption(&g_Config.m_ClRivalsMusicHudY, &g_Config.m_ClRivalsMusicHudY, &Button, Localize("Отступ сверху"), 0, 250);

	Right.HSplitTop(15.0f, nullptr, &Right);
	Right.HSplitTop(60.0f, &Label, &Right);
	SLabelProperties Props;
	Props.m_MaxWidth = Label.w;
	TextRender()->TextColor(ColorRGBA(0.75f, 0.75f, 0.75f, 1.0f));
	Ui()->DoLabel(&Label,
		Localize("Источники: Spotify, браузеры (YouTube, Яндекс Музыка, VK, SoundCloud...), Яндекс Музыка, AIMP, "
			 "Windows Media Player и любые плееры, которые видны в регуляторе громкости Windows.\n"
			 "Бинды в игре: bind f5 rivals_music_toggle / bind f6 rivals_music_next / bind f4 rivals_music_prev"),
		11.0f, TEXTALIGN_TL, Props);
	TextRender()->TextColor(TextRender()->DefaultTextColor());
}
