/* RIVALS: "Сейчас играет" из системы (Spotify, браузеры, плееры).
 * На Windows 10/11 используется Global System Media Transport Controls —
 * тот же источник, что и всплывающий регулятор громкости Windows.
 */
#ifndef GAME_CLIENT_COMPONENTS_RIVALS_MEDIA_SESSION_H
#define GAME_CLIENT_COMPONENTS_RIVALS_MEDIA_SESSION_H

#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>

struct SRivalsTrack
{
	bool m_Available = false; // есть активный источник музыки
	bool m_Playing = false;
	std::string m_Title;
	std::string m_Artist;
	std::string m_Source; // "Spotify", "Google Chrome", "Яндекс Музыка" ...
	double m_PositionSec = 0.0;
	double m_DurationSec = 0.0;
	int m_SessionCount = 0; // сколько приложений сейчас отдают музыку
};

class CRivalsMediaSession
{
public:
	enum ECommand
	{
		CMD_NONE = 0,
		CMD_TOGGLE,
		CMD_NEXT,
		CMD_PREV,
		CMD_NEXT_SOURCE,
	};

	~CRivalsMediaSession() { Stop(); }

	void Start();
	void Stop();

	// Потокобезопасный снимок текущего трека (позиция интерполируется).
	SRivalsTrack Get() const;
	void Send(ECommand Cmd) { m_Command.store(Cmd); }

	static bool Supported();

private:
	void ThreadFunc();

	mutable std::mutex m_Mutex;
	SRivalsTrack m_Track;
	std::chrono::steady_clock::time_point m_SnapshotTime;
	std::string m_PinnedSource; // выбран вручную кнопкой "сменить источник"

	std::thread m_Thread;
	std::atomic<bool> m_Running{false};
	std::atomic<int> m_Command{CMD_NONE};
};

#endif
