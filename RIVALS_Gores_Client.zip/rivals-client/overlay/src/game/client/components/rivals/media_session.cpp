#include "media_session.h"

#if defined(CONF_FAMILY_WINDOWS)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Control.h>
using namespace winrt::Windows::Media::Control;
#endif

#include <algorithm>
#include <cctype>

static std::string ToLower(std::string s)
{
	std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)std::tolower(c); });
	return s;
}

// AppUserModelId -> понятное имя источника
static std::string FriendlySource(const std::string &Id)
{
	const std::string L = ToLower(Id);
	struct SMap
	{
		const char *m_pKey;
		const char *m_pName;
	};
	static const SMap s_aMap[] = {
		{"spotify", "Spotify"},
		{"yandex", "Яндекс"},
		{"msedge", "Microsoft Edge"},
		{"chrome", "Google Chrome"},
		{"firefox", "Firefox"},
		{"308046b0af4a39cb", "Firefox"},
		{"opera", "Opera"},
		{"brave", "Brave"},
		{"vivaldi", "Vivaldi"},
		{"zunemusic", "Windows Media Player"},
		{"music.ui", "Windows Media Player"},
		{"vlc", "VLC"},
		{"aimp", "AIMP"},
		{"foobar", "foobar2000"},
		{"applemusic", "Apple Music"},
		{"itunes", "iTunes"},
		{"deezer", "Deezer"},
		{"soundcloud", "SoundCloud"},
		{"vk", "VK"},
		{"telegram", "Telegram"},
		{"discord", "Discord"},
	};
	for(const auto &Entry : s_aMap)
		if(L.find(Entry.m_pKey) != std::string::npos)
			return Entry.m_pName;

	// запасной вариант: "C:\\path\\App.exe" / "Pkg_xxx!App" -> "App"
	std::string Name = Id;
	size_t Pos = Name.find_last_of("\\/!");
	if(Pos != std::string::npos)
		Name = Name.substr(Pos + 1);
	if(Name.size() > 4 && ToLower(Name.substr(Name.size() - 4)) == ".exe")
		Name.resize(Name.size() - 4);
	return Name.empty() ? std::string("?") : Name;
}

bool CRivalsMediaSession::Supported()
{
#if defined(CONF_FAMILY_WINDOWS)
	return true;
#else
	return false;
#endif
}

void CRivalsMediaSession::Start()
{
	if(!Supported() || m_Running.load())
		return;
	m_Running.store(true);
	m_Thread = std::thread([this]() { ThreadFunc(); });
}

void CRivalsMediaSession::Stop()
{
	m_Running.store(false);
	if(m_Thread.joinable())
		m_Thread.join();
}

SRivalsTrack CRivalsMediaSession::Get() const
{
	std::lock_guard<std::mutex> Lock(m_Mutex);
	SRivalsTrack Track = m_Track;
	if(Track.m_Playing)
	{
		Track.m_PositionSec += std::chrono::duration<double>(std::chrono::steady_clock::now() - m_SnapshotTime).count();
		if(Track.m_DurationSec > 0.0 && Track.m_PositionSec > Track.m_DurationSec)
			Track.m_PositionSec = Track.m_DurationSec;
	}
	return Track;
}

void CRivalsMediaSession::ThreadFunc()
{
#if defined(CONF_FAMILY_WINDOWS)
	try
	{
		winrt::init_apartment(winrt::apartment_type::multi_threaded);
	}
	catch(...)
	{
	}

	GlobalSystemMediaTransportControlsSessionManager Manager{nullptr};

	while(m_Running.load())
	{
		SRivalsTrack Track;
		try
		{
			if(!Manager)
				Manager = GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();

			auto Sessions = Manager.GetSessions();
			const uint32_t Count = Sessions.Size();
			Track.m_SessionCount = (int)Count;

			auto IsPlaying = [](const GlobalSystemMediaTransportControlsSession &S) {
				return S.GetPlaybackInfo().PlaybackStatus() == GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing;
			};

			// 1) источник, выбранный вручную
			GlobalSystemMediaTransportControlsSession Session{nullptr};
			int SessionIndex = -1;
			if(!m_PinnedSource.empty())
			{
				for(uint32_t i = 0; i < Count; i++)
					if(winrt::to_string(Sessions.GetAt(i).SourceAppUserModelId()) == m_PinnedSource)
					{
						Session = Sessions.GetAt(i);
						SessionIndex = (int)i;
					}
				if(!Session)
					m_PinnedSource.clear(); // приложение закрыли — возвращаемся к авто
			}
			// 2) авто: текущая сессия, если играет; иначе любая играющая; иначе текущая
			if(!Session)
			{
				auto Current = Manager.GetCurrentSession();
				if(Current && IsPlaying(Current))
					Session = Current;
				for(uint32_t i = 0; !Session && i < Count; i++)
					if(IsPlaying(Sessions.GetAt(i)))
						Session = Sessions.GetAt(i);
				if(!Session)
					Session = Current;
				if(!Session && Count > 0)
					Session = Sessions.GetAt(0);
				if(Session)
				{
					const auto Id = Session.SourceAppUserModelId();
					for(uint32_t i = 0; i < Count; i++)
						if(Sessions.GetAt(i).SourceAppUserModelId() == Id)
							SessionIndex = (int)i;
				}
			}

			const int Cmd = m_Command.exchange(CMD_NONE);
			if(Cmd == CMD_NEXT_SOURCE && Count > 1)
			{
				const uint32_t Next = (uint32_t)((SessionIndex + 1) % (int)Count);
				Session = Sessions.GetAt(Next);
				m_PinnedSource = winrt::to_string(Session.SourceAppUserModelId());
			}
			else if(Session)
			{
				if(Cmd == CMD_TOGGLE)
					Session.TryTogglePlayPauseAsync().get();
				else if(Cmd == CMD_NEXT)
					Session.TrySkipNextAsync().get();
				else if(Cmd == CMD_PREV)
					Session.TrySkipPreviousAsync().get();
			}

			if(Session)
			{
				Track.m_Available = true;
				Track.m_Source = FriendlySource(winrt::to_string(Session.SourceAppUserModelId()));
				Track.m_Playing = IsPlaying(Session);

				auto Props = Session.TryGetMediaPropertiesAsync().get();
				if(Props)
				{
					Track.m_Title = winrt::to_string(Props.Title());
					Track.m_Artist = winrt::to_string(Props.Artist());
				}

				auto Timeline = Session.GetTimelineProperties();
				using Seconds = std::chrono::duration<double>;
				const double StartSec = Seconds(Timeline.StartTime()).count();
				const double EndSec = Seconds(Timeline.EndTime()).count();
				Track.m_DurationSec = std::max(0.0, EndSec - StartSec);
				Track.m_PositionSec = std::max(0.0, Seconds(Timeline.Position()).count() - StartSec);
				if(Track.m_Playing)
				{
					// позиция в Windows обновляется редко — досчитываем с момента последнего обновления
					const double Delta = Seconds(winrt::clock::now() - Timeline.LastUpdatedTime()).count();
					if(Delta > 0.0 && Delta < 6 * 3600.0)
						Track.m_PositionSec += Delta;
				}
				if(Track.m_DurationSec > 0.0)
					Track.m_PositionSec = std::min(Track.m_PositionSec, Track.m_DurationSec);
			}
		}
		catch(...)
		{
			Manager = nullptr; // пересоздадим на следующей итерации
			Track = SRivalsTrack();
		}

		{
			std::lock_guard<std::mutex> Lock(m_Mutex);
			m_Track = Track;
			m_SnapshotTime = std::chrono::steady_clock::now();
		}

		// опрос раз в ~500 мс, сразу просыпаемся по команде
		for(int i = 0; i < 10 && m_Running.load() && m_Command.load() == CMD_NONE; i++)
			std::this_thread::sleep_for(std::chrono::milliseconds(50));
	}

	Manager = nullptr;
	winrt::uninit_apartment();
#endif
}
