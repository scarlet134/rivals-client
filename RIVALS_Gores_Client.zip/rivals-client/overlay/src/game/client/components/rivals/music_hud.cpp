#include "music_hud.h"

#include <base/math.h>
#include <base/system.h>
#include <engine/client.h>
#include <engine/graphics.h>
#include <engine/shared/config.h>
#include <engine/textrender.h>
#include <game/client/gameclient.h>
#include <game/client/ui.h>

#include <cmath>

static void FormatTime(double Sec, char *pBuf, int Size)
{
	const int Total = maximum(0, (int)Sec);
	str_format(pBuf, Size, "%d:%02d", Total / 60, Total % 60);
}

void CRivalsMusicHud::OnConsoleInit()
{
	Console()->Register("rivals_music_toggle", "", CFGFLAG_CLIENT, ConToggle, this, "RIVALS: play/pause");
	Console()->Register("rivals_music_next", "", CFGFLAG_CLIENT, ConNext, this, "RIVALS: next track");
	Console()->Register("rivals_music_prev", "", CFGFLAG_CLIENT, ConPrev, this, "RIVALS: previous track");
	Console()->Register("rivals_music_source", "", CFGFLAG_CLIENT, ConSource, this, "RIVALS: switch music source (Spotify/browser/...)");
}

void CRivalsMusicHud::ConToggle(IConsole::IResult *pResult, void *pUserData) { ((CRivalsMusicHud *)pUserData)->m_Media.Send(CRivalsMediaSession::CMD_TOGGLE); }
void CRivalsMusicHud::ConNext(IConsole::IResult *pResult, void *pUserData) { ((CRivalsMusicHud *)pUserData)->m_Media.Send(CRivalsMediaSession::CMD_NEXT); }
void CRivalsMusicHud::ConPrev(IConsole::IResult *pResult, void *pUserData) { ((CRivalsMusicHud *)pUserData)->m_Media.Send(CRivalsMediaSession::CMD_PREV); }
void CRivalsMusicHud::ConSource(IConsole::IResult *pResult, void *pUserData) { ((CRivalsMusicHud *)pUserData)->m_Media.Send(CRivalsMediaSession::CMD_NEXT_SOURCE); }

void CRivalsMusicHud::OnInit()
{
	m_Media.Start();
}

void CRivalsMusicHud::OnShutdown()
{
	m_Media.Stop();
}

void CRivalsMusicHud::RenderInfo(CUIRect Rect, const SRivalsTrack &Track, float FontSize)
{
	const float Rounding = FontSize * 0.6f;
	Rect.Draw(ColorRGBA(0.0f, 0.0f, 0.0f, 0.45f), IGraphics::CORNER_ALL, Rounding);

	CUIRect Inner, Eq, Text, Line1, Line2, Progress;
	Rect.Margin(FontSize * 0.45f, &Inner);

	// полоска прогресса внизу
	Inner.HSplitBottom(FontSize * 0.22f, &Inner, &Progress);
	Inner.HSplitBottom(FontSize * 0.25f, &Inner, nullptr);

	// эквалайзер слева (анимируется, когда музыка играет)
	Inner.VSplitLeft(FontSize * 1.3f, &Eq, &Text);
	Text.VSplitLeft(FontSize * 0.4f, nullptr, &Text);
	{
		const float BarW = Eq.w / 4.0f;
		const float t = LocalTime();
		const ColorRGBA Accent = Track.m_Playing ? ColorRGBA(0.2f, 1.0f, 0.55f, 0.95f) : ColorRGBA(0.6f, 0.6f, 0.6f, 0.8f);
		for(int i = 0; i < 3; i++)
		{
			float k = 0.25f;
			if(Track.m_Playing)
				k = 0.3f + 0.7f * std::fabs(std::sin(t * (5.0f + i * 1.7f) + i * 1.3f));
			CUIRect Bar;
			Bar.w = BarW * 0.8f;
			Bar.h = Eq.h * k;
			Bar.x = Eq.x + i * (BarW * 1.35f);
			Bar.y = Eq.y + Eq.h - Bar.h;
			Bar.Draw(Accent, IGraphics::CORNER_ALL, Bar.w * 0.3f);
		}
	}

	Text.HSplitMid(&Line1, &Line2);

	// строка 1: название трека
	SLabelProperties Props;
	Props.m_MaxWidth = Line1.w;
	Props.m_EllipsisAtEnd = true;
	const char *pTitle = Track.m_Title.empty() ? "—" : Track.m_Title.c_str();
	TextRender()->TextColor(ColorRGBA(1.0f, 1.0f, 1.0f, 1.0f));
	Ui()->DoLabel(&Line1, pTitle, FontSize, TEXTALIGN_ML, Props);

	// строка 2: исполнитель · источник        время
	char aTime[64] = "";
	if(Track.m_DurationSec > 0.0)
	{
		char aPos[16], aDur[16];
		FormatTime(Track.m_PositionSec, aPos, sizeof(aPos));
		FormatTime(Track.m_DurationSec, aDur, sizeof(aDur));
		str_format(aTime, sizeof(aTime), "%s / %s", aPos, aDur);
	}
	const float SmallSize = FontSize * 0.8f;
	CUIRect TimeRect = Line2;
	if(aTime[0])
	{
		const float TimeW = TextRender()->TextWidth(SmallSize, aTime, -1, -1.0f) + FontSize * 0.3f;
		Line2.VSplitRight(TimeW, &Line2, &TimeRect);
	}
	char aSub[512];
	if(Track.m_Artist.empty())
		str_copy(aSub, Track.m_Source.c_str(), sizeof(aSub));
	else
		str_format(aSub, sizeof(aSub), "%s · %s", Track.m_Artist.c_str(), Track.m_Source.c_str());
	Props.m_MaxWidth = Line2.w;
	TextRender()->TextColor(ColorRGBA(0.8f, 0.8f, 0.8f, 1.0f));
	Ui()->DoLabel(&Line2, aSub, SmallSize, TEXTALIGN_ML, Props);
	if(aTime[0])
		Ui()->DoLabel(&TimeRect, aTime, SmallSize, TEXTALIGN_MR);
	TextRender()->TextColor(TextRender()->DefaultTextColor());

	// прогресс
	Progress.Draw(ColorRGBA(1.0f, 1.0f, 1.0f, 0.15f), IGraphics::CORNER_ALL, Progress.h * 0.5f);
	if(Track.m_DurationSec > 0.0)
	{
		CUIRect Fill = Progress;
		Fill.w = Progress.w * clamp((float)(Track.m_PositionSec / Track.m_DurationSec), 0.0f, 1.0f);
		if(Fill.w > 0.0f)
			Fill.Draw(ColorRGBA(0.2f, 1.0f, 0.55f, 0.9f), IGraphics::CORNER_ALL, Progress.h * 0.5f);
	}
}

void CRivalsMusicHud::OnRender()
{
	if(!g_Config.m_ClRivalsMusicHud)
		return;
	if(Client()->State() != IClient::STATE_ONLINE && Client()->State() != IClient::STATE_DEMOPLAYBACK)
		return;

	const SRivalsTrack Track = m_Media.Get();
	if(!Track.m_Available || (Track.m_Title.empty() && Track.m_Artist.empty()))
		return;
	if(!Track.m_Playing && g_Config.m_ClRivalsMusicHudHidePaused)
		return;

	const float Height = 300.0f;
	const float Width = Height * Graphics()->ScreenAspect();
	Graphics()->MapScreen(0.0f, 0.0f, Width, Height);

	const float FontSize = 5.5f;
	CUIRect Card;
	Card.w = 140.0f;
	Card.h = InfoHeight(FontSize);
	Card.y = (float)g_Config.m_ClRivalsMusicHudY;
	if(g_Config.m_ClRivalsMusicHudAlign == 0)
		Card.x = 5.0f;
	else if(g_Config.m_ClRivalsMusicHudAlign == 2)
		Card.x = Width - Card.w - 5.0f;
	else
		Card.x = (Width - Card.w) / 2.0f;

	RenderInfo(Card, Track, FontSize);
}
