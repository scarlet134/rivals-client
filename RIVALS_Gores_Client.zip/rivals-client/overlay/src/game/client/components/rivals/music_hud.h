/* RIVALS: мини-плеер сверху экрана во время игры + общий виджет для меню. */
#ifndef GAME_CLIENT_COMPONENTS_RIVALS_MUSIC_HUD_H
#define GAME_CLIENT_COMPONENTS_RIVALS_MUSIC_HUD_H

#include <engine/console.h>
#include <game/client/component.h>
#include <game/client/ui_rect.h>

#include "media_session.h"

class CRivalsMusicHud : public CComponent
{
public:
	int Sizeof() const override { return sizeof(*this); }
	void OnConsoleInit() override;
	void OnInit() override;
	void OnShutdown() override;
	void OnRender() override;

	CRivalsMediaSession &Media() { return m_Media; }

	// Высота карточки для заданного размера шрифта.
	static float InfoHeight(float FontSize) { return FontSize * 3.3f; }
	// Рисует карточку трека: эквалайзер, название, исполнитель, источник, прогресс.
	void RenderInfo(CUIRect Rect, const SRivalsTrack &Track, float FontSize);

private:
	static void ConToggle(IConsole::IResult *pResult, void *pUserData);
	static void ConNext(IConsole::IResult *pResult, void *pUserData);
	static void ConPrev(IConsole::IResult *pResult, void *pUserData);
	static void ConSource(IConsole::IResult *pResult, void *pUserData);

	CRivalsMediaSession m_Media;
};

#endif
