#!/usr/bin/env python3
"""RIVALS Client: накладывает наши изменения на чистый исходник DDNet (github.com/ddnet/ddnet).

Использование:  python scripts/apply_rivals.py <путь_к_ddnet>

Скрипт копирует overlay/src в дерево DDNet и вносит точечные правки по "якорям".
Если якорь не найден (DDNet обновился), скрипт падает с понятной ошибкой,
а не собирает сломанный клиент.
"""
import re
import shutil
import sys
from pathlib import Path

MARK = "RIVALS"
ROOT = Path(__file__).resolve().parent.parent

NEW_CLIENT_FILES = [
    "components/menus_rivals.cpp",
    "components/rivals/media_session.cpp",
    "components/rivals/media_session.h",
    "components/rivals/music_hud.cpp",
    "components/rivals/music_hud.h",
]

CONFIG_VARS = '''
// ---- RIVALS Client ----
MACRO_CONFIG_STR(ClRivalsFont, cl_rivals_font, 128, "", CFGFLAG_CLIENT | CFGFLAG_SAVE, "RIVALS: custom font file from the fonts folder (empty = default)")
MACRO_CONFIG_INT(ClRivalsMusicHud, cl_rivals_music_hud, 1, 0, 1, CFGFLAG_CLIENT | CFGFLAG_SAVE, "RIVALS: show now playing music HUD")
MACRO_CONFIG_INT(ClRivalsMusicHudHidePaused, cl_rivals_music_hud_hide_paused, 0, 0, 1, CFGFLAG_CLIENT | CFGFLAG_SAVE, "RIVALS: hide music HUD while paused")
MACRO_CONFIG_INT(ClRivalsMusicHudAlign, cl_rivals_music_hud_align, 1, 0, 2, CFGFLAG_CLIENT | CFGFLAG_SAVE, "RIVALS: music HUD alignment (0=left, 1=center, 2=right)")
MACRO_CONFIG_INT(ClRivalsMusicHudY, cl_rivals_music_hud_y, 18, 0, 250, CFGFLAG_CLIENT | CFGFLAG_SAVE, "RIVALS: music HUD offset from top")
'''

FONT_HOOK = r'''
		// ---- RIVALS: custom font (cl_rivals_font) ----
		if(g_Config.m_ClRivalsFont[0] != '\0')
		{
			char aRivalsPath[IO_MAX_PATH_LENGTH];
			str_format(aRivalsPath, sizeof(aRivalsPath), "fonts/%s", g_Config.m_ClRivalsFont);
			void *pRivalsData = nullptr;
			unsigned RivalsSize = 0;
			if(Storage()->ReadFile(aRivalsPath, IStorage::TYPE_ALL, &pRivalsData, &RivalsSize))
			{
				if(LoadFontCollection(aRivalsPath, static_cast<FT_Byte *>(pRivalsData), (FT_Long)RivalsSize))
				{
					m_vpFontData.push_back(pRivalsData);
					FT_Face RivalsFace;
					if(FT_New_Memory_Face(m_FTLibrary, static_cast<FT_Byte *>(pRivalsData), (FT_Long)RivalsSize, 0, &RivalsFace) == 0)
					{
						char aRivalsFamily[256];
						str_format(aRivalsFamily, sizeof(aRivalsFamily), "%s %s", RivalsFace->family_name, RivalsFace->style_name);
						FT_Done_Face(RivalsFace);
						m_pGlyphMap->SetDefaultFaceByName(aRivalsFamily);
						// original font stays as fallback (cyrillic, special symbols)
						if(DefaultFace.type == json_string)
							m_pGlyphMap->AddFallbackFaceByName(DefaultFace.u.string.ptr);
						char aRivalsMsg[512];
						str_format(aRivalsMsg, sizeof(aRivalsMsg), "RIVALS custom font '%s'", aRivalsFamily);
						Console()->Print(IConsole::OUTPUT_LEVEL_STANDARD, "rivals", aRivalsMsg);
					}
				}
				else
					free(pRivalsData);
			}
		}
'''


class PatchError(Exception):
    pass


def read(p: Path) -> str:
    if not p.exists():
        raise PatchError(f"файл не найден: {p}")
    return p.read_text(encoding="utf-8")


def write(p: Path, s: str):
    p.write_text(s, encoding="utf-8", newline="\n")


def sub_once(text: str, pattern: str, repl, what: str, flags=0) -> str:
    new, n = re.subn(pattern, repl, text, count=1, flags=flags)
    if n != 1:
        raise PatchError(f"якорь не найден: {what}")
    return new


def patch_config(ddnet: Path):
    p = ddnet / "src/engine/shared/config_variables.h"
    s = read(p)
    if "ClRivalsFont" in s:
        return
    pat = r"(MACRO_CONFIG_INT\(UiSettingsPage, ui_settings_page, 0, 0, )(\d+)(,[^\n]*\n)"
    s = sub_once(s, pat, lambda m: f"{m.group(1)}{int(m.group(2)) + 1}{m.group(3)}{CONFIG_VARS}", "UiSettingsPage в config_variables.h")
    write(p, s)


def patch_menus_h(ddnet: Path):
    p = ddnet / "src/game/client/components/menus.h"
    s = read(p)
    if "SETTINGS_RIVALS" in s:
        return
    s = sub_once(s, r"(?m)^([ \t]*)(SETTINGS_LENGTH\b)", r"\1SETTINGS_RIVALS,\n\1\2", "enum SETTINGS_LENGTH в menus.h")
    m = re.search(r"void RenderSettings\(CUIRect MainView\);", s) or re.search(r"void RenderSettingsCredits\(CUIRect MainView\);", s)
    if not m:
        raise PatchError("якорь не найден: RenderSettings(CUIRect MainView) в menus.h")
    s = s[:m.end()] + "\n\t// RIVALS: menus_rivals.cpp\n\tvoid RenderSettingsRivals(CUIRect MainView);" + s[m.end():]
    write(p, s)


def patch_menus_settings(ddnet: Path):
    p = ddnet / "src/game/client/components/menus_settings.cpp"
    s = read(p)
    if "RenderSettingsRivals" in s:
        return
    s = sub_once(s, r"(apTabs\[SETTINGS_LENGTH\]\s*=\s*\{[^;]*?)(\s*\};)", lambda m: m.group(1) + ',\n\t\t"RIVALS"' + m.group(2),
                 "массив вкладок apTabs[SETTINGS_LENGTH] в menus_settings.cpp")
    if not re.search(r"\n([ \t]*)(if\(g_Config\.m_UiSettingsPage == SETTINGS_LANGUAGE\))", s):
        s = sub_once(s, r"\n([ \t]*)(else if\(g_Config\.m_UiSettingsPage == SETTINGS_)",
                     lambda m: ("\n" + m.group(1) + "else if(g_Config.m_UiSettingsPage == SETTINGS_RIVALS)\n" + m.group(1) + "{\n" + m.group(1) +
                                "\tm_pBackground->ChangePosition(CMenuBackground::POS_SETTINGS_DDNET);\n" + m.group(1) +
                                "\tRenderSettingsRivals(MainView);\n" + m.group(1) + "}\n" + m.group(1) + m.group(2)),
                     "ветка m_UiSettingsPage в RenderSettings")
        write(p, s)
        return
    s = sub_once(s, r"\n([ \t]*)(if\(g_Config\.m_UiSettingsPage == SETTINGS_LANGUAGE\))",
                 lambda m: ("\n" + m.group(1) + "if(g_Config.m_UiSettingsPage == SETTINGS_RIVALS)\n" + m.group(1) + "{\n" + m.group(1) +
                            "\tm_pBackground->ChangePosition(CMenuBackground::POS_SETTINGS_DDNET);\n" + m.group(1) +
                            "\tRenderSettingsRivals(MainView);\n" + m.group(1) + "}\n" + m.group(1) + "else " + m.group(2)),
                 "if(g_Config.m_UiSettingsPage == SETTINGS_LANGUAGE) в RenderSettings")
    write(p, s)


def patch_gameclient(ddnet: Path):
    ph = ddnet / "src/game/client/gameclient.h"
    s = read(ph)
    if "m_RivalsMusicHud" not in s:
        s = sub_once(s, r'(#include [<"](?:game/client/)?components/hud\.h[>"][^\n]*\n)',
                     r'\1#include <game/client/components/rivals/music_hud.h>\n', "#include hud.h в gameclient.h")
        s = sub_once(s, r"(\n([ \t]*)CHud m_Hud;)", r"\1\n\2CRivalsMusicHud m_RivalsMusicHud;", "CHud m_Hud в gameclient.h")
        write(ph, s)
    pc = ddnet / "src/game/client/gameclient.cpp"
    s = read(pc)
    if "m_RivalsMusicHud" not in s:
        s = sub_once(s, r"(m_vpAll\.insert\(m_vpAll\.end\(\),\s*\{.*?&m_Hud,)", r"\1\n\t\t\t\t\t &m_RivalsMusicHud,",
                     "&m_Hud в списке компонентов m_vpAll", flags=re.S)
        write(pc, s)


def patch_text(ddnet: Path):
    p = ddnet / "src/engine/client/text.cpp"
    s = read(p)
    if "m_ClRivalsFont" in s:
        return
    m0 = re.search(r"(?:bool|void) LoadFonts\(\)", s)
    if not m0:
        raise PatchError("якорь не найден: LoadFonts() в text.cpp")
    end = s.find("\n\t}\n", m0.end())
    if end < 0:
        end = len(s)
    idx = s.rfind("json_value_free(pJsonData);", m0.end(), end)
    if idx < 0:
        raise PatchError("якорь не найден: json_value_free(pJsonData) в LoadFonts")
    line_start = s.rfind("\n", 0, idx)
    s = s[:line_start] + FONT_HOOK.rstrip("\n") + s[line_start:]
    if "engine/shared/config.h" not in s:
        s = sub_once(s, r"(#include [^\n]+\n)", r"\1#include <engine/shared/config.h>\n", "первый #include в text.cpp")
    write(p, s)


def patch_cmake(ddnet: Path):
    p = ddnet / "CMakeLists.txt"
    s = read(p)
    if "menus_rivals.cpp" not in s:
        m = re.search(r"set_src\(GAME_CLIENT GLOB_RECURSE src/game/client\n(.*?)\n\)", s, re.S)
        if not m:
            raise PatchError("якорь не найден: set_src(GAME_CLIENT GLOB_RECURSE src/game/client ...) в CMakeLists.txt")
        lines = m.group(1).split("\n")
        indent = re.match(r"[ \t]*", lines[0]).group(0) or "  "
        entries = [l.strip() for l in lines if l.strip()]
        for f in NEW_CLIENT_FILES:
            if f not in entries:
                entries.append(f)
        # DDNet проверяет, что список файлов совпадает с содержимым папки и отсортирован
        entries.sort()
        body = "\n".join(indent + e for e in entries)
        s = s[:m.start(1)] + body + s[m.end(1):]
    if "windowsapp" not in s:
        # C++/WinRT (GSMTC — Spotify, браузеры, плееры) требует windowsapp.lib
        s = sub_once(s, r"(set\(PLATFORM_CLIENT_LIBS opengl32[^)\n]*)\)", r"\1 windowsapp)",
                     "PLATFORM_CLIENT_LIBS (windows) в CMakeLists.txt")
    write(p, s)


def copy_overlay(ddnet: Path):
    src = ROOT / "overlay" / "src"
    for f in src.rglob("*"):
        if f.is_file():
            dst = ddnet / "src" / f.relative_to(src)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst)
            if dst.suffix in (".cpp", ".h"):
                txt = dst.read_text(encoding="utf-8")
                ms = (ddnet / "src/game/client/components/menus_settings.cpp").read_text(encoding="utf-8", errors="ignore")
                if "UI()->DoLabel" in ms and "Ui()->DoLabel" not in ms:
                    txt = txt.replace("Ui()->", "UI()->")
                if "Client()->ViewFile" not in ms:
                    txt = txt.replace("Client()->ViewFile(aBuf);", "open_file(aBuf);")
                dst.write_text(txt, encoding="utf-8", newline="\n")
            print(f"  + src/{f.relative_to(src).as_posix()}")


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    ddnet = Path(sys.argv[1]).resolve()
    print(f"RIVALS Client -> {ddnet}")
    steps = [("копирование файлов", copy_overlay), ("config_variables.h", patch_config), ("menus.h", patch_menus_h),
             ("menus_settings.cpp", patch_menus_settings), ("gameclient.h/.cpp", patch_gameclient),
             ("text.cpp (шрифты)", patch_text), ("CMakeLists.txt", patch_cmake)]
    try:
        for name, fn in steps:
            print(f"[*] {name}")
            fn(ddnet)
    except PatchError as e:
        print(f"\n[ОШИБКА] {e}\nВероятно, DDNet обновился. Закрепите старую версию (DDNET_REF в build.yml) или обновите якорь в apply_rivals.py.")
        sys.exit(1)
    print("[OK] Все патчи применены.")


if __name__ == "__main__":
    main()
